__version__ = '0.7.1'

__doc__ = '''PyWeather branch; download real-time data from Davis Vantage Pro
weather stations, upload weather data to sites (e.g. wunderground.com), and
various meteorological conversion functions.'''
